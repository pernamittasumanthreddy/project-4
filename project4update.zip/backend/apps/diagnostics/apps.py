from django.apps import AppConfig

class DiagnosticsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.diagnostics'
    verbose_name = 'Member 4 - Laboratory & Radiology Diagnostics'
