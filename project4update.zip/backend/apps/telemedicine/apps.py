from django.apps import AppConfig

class TelemedicineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.telemedicine'
    verbose_name = 'Member 7 - Telemedicine & WebRTC Virtual Consultations'
