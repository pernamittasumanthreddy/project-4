from django.apps import AppConfig

class PharmacyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.pharmacy'
    verbose_name = 'Member 5 - Pharmacy & Medication Inventory'
