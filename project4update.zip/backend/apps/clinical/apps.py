from django.apps import AppConfig

class ClinicalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.clinical'
    verbose_name = 'Member 3 - Clinical Encounters & Electronic Medical Records'
